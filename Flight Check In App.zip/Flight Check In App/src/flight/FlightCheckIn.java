package flight;

import java.util.Scanner;

import java.util.Scanner;
 
public class FlightCheckIn {

	private String FirstName1;
	
	private String LastName1;
	
	private String Email1;

	private String PhoneNumber;
	private String ToDestination;
	private String FromDestination;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FlightCheckIn obj1 = new FlightCheckIn();
		obj1.takeinput();
		obj1.Displayoutput();

	}
	
	public void takeinput () { 
		Scanner keyboard = new Scanner(System.in);
		System.out.println("What is your First Name?");
		FirstName1 = keyboard.next();
		
		System.out.println("What is your Last Name?");
		LastName1 = keyboard.next();
		
		System.out.println("What is your email?");
		Email1 = keyboard.next();
		
		System.out.println("What is your Phone Number?");
		PhoneNumber = keyboard.next();
		
		System.out.println("Where are you going?");
		ToDestination = keyboard.next();
		
		System.out.println("Where are you leaving from?");
		FromDestination = keyboard.next();
		
	}
	
	public void Displayoutput () { 
		System.out.println("The Passengers First Name is :");
		System.out.println(FirstName1);
		
		System.out.println("The Passengers Last Name is :");
		System.out.println(LastName1);
		
		System.out.println("The Passengers Email is :");
		System.out.println(Email1);
		
		System.out.println("The Passengers Phone Number is :");
		System.out.println(PhoneNumber);
		
		System.out.println("The Passenger is headed to :");
		System.out.println(ToDestination);
		
		System.out.println("The passenger is leaving from :");
		System.out.println(FromDestination);
	}
	}
