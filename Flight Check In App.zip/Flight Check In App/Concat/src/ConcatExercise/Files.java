package ConcatExercise;

import java.io.*;

public class Files {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try {
		//Creates a File Reader object
		FileReader file = new FileReader("/Users/timothymansfield-thompson/Desktop/Workspace/Flight Check In App/Concat/File3");
		
		char c;
		int i;
		
		//reads till the end of the stream
			while ((i = file.read()) !=-1) { 
			
			//converts integer to character
			c = (char)i;
			
			//prints character
			System.out.print(c);
	}
	
			file.close();
			
	} 
	catch (FileNotFoundException e) {
		
		e.printStackTrace();
	}
	catch (IOException e) {
		
		e.printStackTrace();
	}
}
}

