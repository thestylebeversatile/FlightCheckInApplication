package ConcatExercise;

public class Concat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String x = "Timothy";
		String y = "Thompson";
		
		//Concat is combining to Strings together. 
		
		System.out.println(x.concat(y));
		
	}

}
