package ConcatExercise;

import java.io.FileWriter;
import java.io.IOException;

public class File1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try {
			FileWriter file = new FileWriter("/Users/timothymansfield-thompson/Desktop/Workspace/Flight Check In App/Concat/File2");
		
		
		file.write("abcdefg");
		
		
		file.close();
		
		System.out.println("Done");
	}
	catch (IOException e) {
		e.printStackTrace();
	}
		
	}

}
