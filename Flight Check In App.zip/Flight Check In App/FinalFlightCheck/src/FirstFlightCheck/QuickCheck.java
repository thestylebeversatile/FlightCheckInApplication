package FirstFlightCheck;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class QuickCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
try {
            
            FileWriter file = new FileWriter("/Users/timothymansfield-thompson/Desktop/Workspace/Flight Check In App/FinalFlightCheck/FlightFile"); //change your filename to file
            BufferedWriter printitinerary = new BufferedWriter(file); // add this line
            printitinerary.write("hello");
            printitinerary.newLine(); // new line of code
            printitinerary.write("hkkkk");   // n
           
            printitinerary.close();
            System.out.println("Done");
           
      } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
      }

	}

}
