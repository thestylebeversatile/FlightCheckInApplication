package FirstFlightCheck;

import java.util.Arrays;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FinalFlight {
	
	
	//Create User Account
	private static String FirstName1;
	private static String LastName1;
	private static String Email1;
	private static String DOB;
	private static String Age;
	private static String PhoneNumber;
	private static String username;
	
	//New Screen: Booking Flight
	private static String destination1;
	private static String destination2;
	private int Passengers;
	private static String TripType; 
	
	//New Screen: Flight Availability Screen
	private String FromTime;
	private String ToTime;
	private String FlightName;
	private String Duration;
	private String Price;
	private int FlightNumber;
	private String [] FromGlobal = new String [3];
	private String [] ToGlobal = new String [3];
	
	//New Screen: Flight Return Screen
	private String FromTime1;
	private String ToTime1;
	private String FlightTime1;
	private String Duration1;
	private String Price1;
	private String TripType1;
	private String FlightName1;
	private int FlightNumber1;
	
	//String Call
	private  String [ ] fromtimeglobal =  new String[3];
	private String [ ] totimeglobal = new String[3];
	private static String [ ] flightnameglobal =  new String[3];
	private static String [ ] durationglobal =  new String[3];
	private static String [ ] priceglobal =  new String[3];
	private static String [ ] flightnumberglobal =  new String[3];
	
	private static String [ ] fromtimeglobal1 =  new String[3];
	private static String [ ] totimeglobal1 =  new String[3];;
	private static String [ ] flightnameglobal1 =  new String[3];
	private static String [ ] durationglobal1 =  new String[3];
	private static String [ ] priceglobal1 =  new String[3];
	private static String [ ] flightnumberglobal1 =  new String[3];
	

	private int flag =-1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		FinalFlight obj1 = new FinalFlight();
		obj1.CreateUserAccount();
		obj1.BookTicketScreen();
		obj1.FlightAvailScreen();
		obj1.FlightReturnScreen();
		obj1.PrintFlightSummaryScreen();
		
	}
	
	public static void CreateUserAccount () {
		System.out.println("Create User Account");
		System.out.println("");
		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter First Name :");
		FirstName1 = keyboard.next();
		
		System.out.println("Enter Last Name :");
		LastName1 = keyboard.next();
		
		System.out.println("Enter email address :");
		Email1 = keyboard.next();
		
		System.out.println("Enter date of Birth :");
		DOB = keyboard.next();
		
		System.out.println("Enter Age.");
		String Age = keyboard.next();
		
		System.out.println("Please enter username :");
		username = keyboard.next();
		
		System.out.println("Please enter password :");
		String password = keyboard.next();
	
		if (username.length() > 10 ) { 
			System.out.println("Error: Username must be less than 10 characters.");
			
		}	
		
		if (password.length() > 10) { 
			System.out.println("Error: Password must be less than 10 characters.");
		}
		
	
	}
		
		public void BookTicketScreen () { 
		System.out.println(" -|-|-|-|-|-|-|-|-|-|-|-|");
		System.out.println("| Booking Tickets Screen |");
		System.out.println(" -|-|-|-|-|-|-|-|-|-|-|-|");
		
		String [ ] fromdestination = {"FLL", "CHI", "NY"};
		String [ ] todestination = {"FLL", "CHI", "NY"};
		
		Scanner keyboard = new Scanner(System.in); 
		
		int x1 = -1;
		for (int x=0; x < fromdestination.length; x++) {
			
			System.out.println("Where are you flying from? :");
			System.out.println(fromdestination[x]);
			System.out.println("");
			System.out.println("- - - - - - - - - - - - - - - - - ");
			
			
			System.out.println("Where do you want to fly to? :");
			System.out.println(todestination[x]);
			System.out.println("");
			System.out.println("- - - - - - - - - - - - - - - - - ");
			
			
			FromGlobal[x] = fromdestination[x];
			ToGlobal[x] = todestination[x];
			
		}
		
		System.out.println("Choose From Destination :");
		destination1 = keyboard.next();
		
	
		
		int x3=0;
		for (int x=0; x < fromdestination.length; x++) { 
			if (destination1.equals(fromdestination[x])) { 
				System.out.println("Valid Destination");
				break;
				
				
			}
		
			x3++;
		
		}
		
		if(x3 == 3) {
			System.out.println("invalid destination");
		}
		Scanner keyboard2 = new Scanner (System.in);
		System.out.println("Choose To Destination :");
		destination2 = keyboard2.next();
		int x4=0;
		for (int x=0; x < todestination.length; x++) { 
			if (destination2.equals(todestination[x])) { 
				System.out.println("Valid Destination");
				break;
			}
		x4++;
	
			
		}
	
		if(x4==3) {
			System.out.println("Invalid destination");
		}
		Scanner keyboard3 = new Scanner(System.in);
		
		System.out.println("How many passengers :");
		int Passengers = keyboard3.nextInt();
		
		if (Passengers > 5) { 
			System.out.println("Number of Passengers cannot exceed 5");
		}
		
		System.out.println("Trip Type : One way or Round trip ?");
		TripType = keyboard.next();
		
		}
		
		public void FlightAvailScreen() {
			
			System.out.println("-|-|-|-|-|-|-|-|-|-|-|-");
			System.out.println("|  Flight Avail Screen |");
			System.out.println("-|-|-|-|-|-|-|-|-|-|-|-");
			
			String [ ] fromtime = {"8:00 am", "10:00 am", "11:00 am" };
			String [ ] totime = {"10:00 pm", "12:10 pm", "1:30 pm" };
			String [ ] flightname = {"JetBlue", "Delta", "Spirit" };
			String [ ] duration = {"2hr", "2hr 10 min", "2hr 30 in" };
			String [ ] price = {"200","300","400" };
			String [ ] triptype = {"Round-Trip", "One-Way", "One Stop in LA"};
			String [ ] flightnumber = {"23","3456", "789"};
			
		
			Scanner keyboard = new Scanner (System.in);
			
			for (int x=0; x < fromtime.length; x++) { 
				

				System.out.println("From Time :");
				System.out.println(fromtime[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("To Time :");
				System.out.println(totime[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("Airline Flight Name:");
				System.out.println(flightname[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("Flight Duration :");
				System.out.println(duration[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("Price of Flight :");
				System.out.println(price[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("Flight Number :");
				System.out.println(flightnumber[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				
				
				fromtimeglobal[x] = fromtime[x];
				
				System.out.println(fromtimeglobal[x]);
				
				
				totimeglobal[x] = totime[x];
				flightnameglobal[x] = flightname[x];
				durationglobal[x] = duration[x];
				priceglobal[x] = price[x];
				
				flightnumberglobal[x] = flightnumber[x];	
					
				
				
			}
			
			System.out.println("Please enter flight number that you want to choose :");
			Scanner keyboard1 = new Scanner(System.in);
			String FlightNumber = keyboard.next();
			
			
			
			int z1=0;
			for(int z=0; z <fromtime.length; z++) {
				if(FlightNumber.equals(flightnumber[z])) {
					System.out.println("valid flight");
					flag = z;
					break;
				}
				z1++;
				
			}
			
			if(z1==3) {
				System.out.println("invalid flight");
			}
			System.out.println(flag);
		}
		

		public void FlightReturnScreen() {
			System.out.println("-|-|-|-|-|-|-|-|-|-|-|-");
			System.out.println("| Flight Return Screen|");
			System.out.println("-|-|-|-|-|-|-|-|-|-|-|-");
			
			String [ ] fromtime1 = {"8:00", "10:00", "10:50" };
			String [ ] totime1 = {"10:00", "12:00", "1:00" };
			String [ ] flightname1 = {"JetBlue", "Delta", "Spirit" };
			String [ ] duration1 = {"2hr", "2hr", "2hr 10 min" };
			String [ ] price1 = {"100","200","300" };
			String [ ] triptype1 = {"Round-Trip", "One way", "One Stop in LA"};
			String [ ] flightnumber1 = {"101","3246", "219"};
			
			
			Scanner keyboard = new Scanner (System.in);
			
			for (int x=0; x < fromtime1.length; x++) { 


				System.out.println("From Time :");
				System.out.println(fromtime1[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				
				System.out.println("To Time :");
				System.out.println(totime1[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				
				System.out.println("Airline Flight Name:");
				System.out.println(flightname1[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("Flight Duration :");
				System.out.println(duration1[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("Price of Flight :");
				System.out.println(price1[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				System.out.println("Flight Number :");
				System.out.println(flightnumber1[x]);
				System.out.println("");
				System.out.println("- - - - - - - - - - - - - - - - - ");
				
				
				fromtimeglobal1 [x] = fromtime1[x];
				totimeglobal1 [x] = totime1[x];
				flightnameglobal1 [x] = flightname1[x];
				durationglobal1 [x] = duration1[x];
				priceglobal1 [x] = price1[x];
				
				flightnumberglobal [x] = flightnumber1[x];
				
			}

			System.out.println("Please enter flight number that you want to choose :");
			Scanner keyboard1 = new Scanner(System.in);
			String FlightNumber1 = keyboard.next();
			
			int z1=0;
			for(int z=0; z <fromtime1.length; z++) {
				if(FlightNumber1.equals(flightnumber1[z])) {
					System.out.println("valid flight");
					flag = z;
					break;
				}
				z1++;
				
			}
			
			if(z1==3) {
				System.out.println("invalid flight");
			}
			System.out.println(flag);
}

		
		public void PrintFlightSummaryScreen() { 
			System.out.println(" -|-|-|-|-|-|-|-|-|-|-|-|-|-");
			System.out.println("|   *Print Flight Summary*  |");
			System.out.println(" -|-|-|-|-|-|-|-|-|-|-|-|-|-");
			
			System.out.println("");
			System.out.println("");
			
			System.out.println(" - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
			System.out.println("| Your intial Flight Destination Details are as follows : |");
			System.out.println(" - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
			
			System.out.println("");
			
			System.out.println("Airline");
			System.out.println(flightnameglobal[flag]);
			
			System.out.println("");
			System.out.println("Your Flight will be leaving at :");
			System.out.println(fromtimeglobal[flag]);
			
			System.out.println("");
			System.out.println("Your Flight will be arriving at : ");
			System.out.println(totimeglobal[flag]);
			
			System.out.println("");
			System.out.println("You will be leaving from :");
			System.out.println(destination1);
			
			System.out.println("");
			System.out.println("Initial Flight Cost :");
			System.out.println(priceglobal[flag]);
			
			System.out.println("");
			System.out.println("");
			
			System.out.println(" - - - - - - - - - - - - - - - - - - - - - - -");
			System.out.println("| Your Return Flight Details are as follows : |");
			System.out.println(" - - - - - - - - - - - - - - - - - - - - - - -");
			
			System.out.println("");
			
			System.out.println("Airline");
			System.out.println(flightnameglobal1[flag]);
			
			System.out.println("");
			System.out.println("Your Flight will be leaving at :");
			System.out.println(fromtimeglobal1[flag]);
			
			System.out.println("");
			System.out.println("Your Flight will be arriving at : ");
			System.out.println(totimeglobal1[flag]);
			
			System.out.println("");
			System.out.println("You will be leaving from :");
			System.out.println(destination2);
			
			System.out.println("");
			System.out.println("Initial Flight Cost :");
			System.out.println(priceglobal1[flag]);
			
			System.out.println("");
			System.out.println("");
			
			System.out.println(" - - - - - - - - - -");
			System.out.println("| Passenger Details |");
			System.out.println(" - - - - - - - - - -");
			
			System.out.println("The passengers First Name is :");
			System.out.println(FirstName1);
		
			System.out.println("");
			
			System.out.println("The passengers Last Name is :");
			System.out.println(LastName1);
			
			System.out.println("");
			
			System.out.println("The passengers Email Address is :");
			System.out.println(Email1);
			
			System.out.println("");
			
			System.out.println("The passengers Date of Birth is :");
			System.out.println(DOB);
			
			System.out.println("");
			
			System.out.println("The passengers Ticket Number is :");
			System.out.println(username.concat(DOB));
			
			System.out.println("");
			
			System.out.println("The passengers Trip Type is :");
			System.out.println(TripType);
			
			
			
			try {
	            
	            FileWriter file = new FileWriter("/Users/timothymansfield-thompson/Desktop/Workspace/Flight Check In App/FinalFlightCheck/FlightFile"); //change your filename to file
	            BufferedWriter printitinerary = new BufferedWriter(file); // add this line
	            printitinerary.write(TripType);
	            printitinerary.newLine(); // new line of code
	            printitinerary.write(FirstName1);   // n
	            
	            printitinerary.close();
	            System.out.println("Done");
	           
	      } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	      }
			
		}
			
}

