package Collections;

import java.util.*;

public class MathLibrary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		System.out.println(Math.random());
		
		System.out.println(Math.max(13, 14));
		
		System.out.println(Math.min(234, 12436));

	}

}
