package Collections;

import java.util.*;

public class Maps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// declare set
		
		
		Map a1 = new HashMap();
		
		a1.put("hi" , "1");
		System.out.println(a1);
		
		Date obj1 = new Date();
		System.out.println(obj1);

	}

}
