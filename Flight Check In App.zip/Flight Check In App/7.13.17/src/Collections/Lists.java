package Collections;

import java.util.*;

public class Lists {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Declare set
		
		Set s1 = new HashSet();
		
		
		//Add Value
		
		s1.add("hi");
		s1.add("bye");
		s1.add("hi");
		System.out.println(s1);
		
		//declare list
		List a1 = new ArrayList();
		List r1 = new LinkedList();
		
		//add values
		a1.add("hiii");
		System.out.print(a1);
		r1.add("baby");
		System.out.println(r1);

	}

}
