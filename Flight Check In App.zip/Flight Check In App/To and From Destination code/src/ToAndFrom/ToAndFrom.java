package ToAndFrom;

import java.util.Scanner;

public class ToAndFrom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [ ] fromdestination = {"FLL", "Chi", "NY"};
		String [ ] todestination = {"FLL", "Chi", "NY"};
		
		Scanner keyboard = new Scanner (System.in);
		System.out.println("please enter from destination");
		
		String destination1 = keyboard.next();
		
		for (int x=0; x < fromdestination.length; x++) { 
			if (destination1.equals(fromdestination[x])) { 
				System.out.println("Valid Destination");
				break;
				
			}
			else {
				
				System.out.println("Invalid Destination");
				break;
				
			}
			
		}

	}

}
