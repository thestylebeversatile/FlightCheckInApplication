package Username;

import java.util.Scanner;

public class UsernameTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner keyboard = new Scanner (System.in);
		System.out.println("Please enter username :");
		String username = keyboard.next();
		
		System.out.println("Please enter password :");
		String password = keyboard.next();
	
		System.out.println("Enter date of Birth :");
		String DOB = keyboard.next();
		
		System.out.println("Your file name is :");
		String space = " ";
		String result = username.concat(space);
		
		System.out.println(result.concat(DOB));

	if (username.length() > 10) { 
		System.out.println("Username must be less than 10 characters.");
		
	}	
	
	if (password.length() < 6) { 
		System.out.println("Password must be more than 6 characters.");
		
		
	}
	
}
}
